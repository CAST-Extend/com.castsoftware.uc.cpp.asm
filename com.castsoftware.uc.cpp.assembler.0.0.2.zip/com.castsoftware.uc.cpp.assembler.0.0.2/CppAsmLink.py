##############################################################################################
#---------------------------------------------------------------------------------------------
# Created on 
#
# Author: Thangadurai Kandhasamy<t.kandhasamy@castsoftware.com> - TKA
#
# Description: 
#---------------------------------------------------------------------------------------------
##############################################################################################


# import cast_upgrade_1_5_11 # @UnusedImport
from cast.application import create_link
import logging
import cast.application
import traceback
import re
from cast.analysers import CustomObject
from utils.CppAsmObjLinkers import CppAsmLinker as linker

import os
from os import listdir
from os import walk
import traceback
from os.path import basename, splitext
from sqlalchemy.event import legacy


class CppAsmLink(cast.application.ApplicationLevelExtension):

    def __init__(self):   
        self.filename = ""
        self.name = ""
        self.file = ""    
        
        
#        pass   
    
    def end_application(self, application):
        logging.info("CppAsm : Running extension code at the end of an application - CppAsmExtension")
#         nb_links = 0
#         jvlinks = []
#         asdlinks = []
        # for javaclass in application.search_objects(category='JV_METHOD', name =None, load_properties=False):
#         for javaclass in application.search_objects(category='JavaMethod_ASAP', name =None, load_properties=False):
#             #logging.info("javaclass--" +str(javaclass.get_name()))
#             jvlinks.append(javaclass)
#         for asdlobj in application.search_objects(category='ASDL_ASAP', name =None, load_properties=False):
#             #logging.info("asdlobj--" +str(asdlobj.get_name()))
#             asdlinks.append(asdlobj)
        try:
            # fileCount = sum(1 for x in application.get_files(['sourceFile']))
            files = application.get_files(['sourceFile'])
        except Exception as e:
            logging.error("CppAsm : Error selecting sh file set : %s", str(e))
        

        asmGlobalList = list(application.search_objects(category='ASM_GLOBAL', load_properties=False))
        asmModuleList = list(application.search_objects(category='ASM_MODULE', load_properties=False))
        asmSect       = list(application.search_objects(category='ASM_SECT', load_properties=False))

        cppFunctionList  = list(application.search_objects(category='C_FUNCTION', load_properties=False))
        
        cppExternCList  = list(application.search_objects(category='CPP_EXTERN_C', load_properties=False))
        cppExternOSList = list(application.search_objects(category='CPP_EXTERN_OS', load_properties=False))
        
        cppMethodList  = list(application.search_objects(category='C_METHOD', load_properties=False))
        cppLegacyList   = list(application.search_objects(category='CPP_LEGACY_LINKAGE', load_properties=False))
        
        asmcppMethodList = list(application.search_objects(category='ASM_CPP_METHOD', load_properties=False)) 
        
        linker.CppMethodToLegacyLinkage(self, cppMethodList, cppLegacyList)
        linker.CppMethodToExternOSCall(self, cppMethodList, cppExternOSList)       
        linker.CppFunctionToLegacyLinkage(self, cppFunctionList, cppLegacyList)
        linker.CppFunctionToExternOSCall(self, cppFunctionList, cppExternOSList)        
        linker.CppExternOSToAsmSect(self, cppExternOSList, asmSect)
        linker.CppLegacyLinkageToAsmSect(self, cppLegacyList, asmSect)
        linker.CppFunctionToExternC(self, cppFunctionList, cppExternCList)       
        linker.CppExternCToAsmGlobal(self, asmGlobalList, cppExternCList)
        linker.AsmGlobalToAsmModule(self, asmGlobalList, asmModuleList)
        
        linker.AsmSectToAsmcppMethodCall(self, asmcppMethodList, asmSect)


        if not asmcppMethodList is None:
            for asmcppMethodLis in asmcppMethodList:
#                logging.info("asmcppMethod Name: >>>"+ asmcppMethodLis.get_name() )
                checkMethodName = asmcppMethodLis.get_name()
                for file in files:
                    
                    with open(file.get_path(), "r") as f:
                        lines = f.readlines()
#                        print( lines )

                    for line in lines:
                        line = line.replace("\n"," ")
                        line = line.replace("\t"," ")
                        line = line.strip()
                        
                        try:
                            pragmaMaps = re.findall( "pragma\s+map\s*\(\s*(\w+)\s*\,\s*\"("+ checkMethodName +")\"\)", line)
                            if pragmaMaps:
                                matchingFunction = ""
                                for pragmaMap in pragmaMaps:
#                                    logging.info(f.name+"~~~"+pragmaMap[0])
                                    matchingFunction = pragmaMap[0]                                    
                                    
                                    try:
                                        parent = None
                                        child = None
                                        for cppFunctionLis in cppFunctionList:
                                            if cppFunctionLis.get_name() == matchingFunction :
                                                parent = asmcppMethodLis
                                                child = cppFunctionLis
                                                                                                
                                                logging.info("Link this Parent ["+ str(parent.name) +"] to child ["+ str(child.name) +"]")
                                                create_link("callLink", parent, child)
                                                logging.info("Link created for [C_FUNCTION-CPP_EXTERN_C] : ["+ str(parent.name) +"] and ["+ str(child.name) +"]" )
                                    except Exception as e:
                                        logging.error("CppAsm : Exception in C_FUNCTION to CPP_EXTERN_C linking : %s", str(e))
            
                                    break;
                        except Exception as e:
                            logging.info("CppAsm : Error Creating CPP_PRAGMA_MAP_FUNCTION Artifact : %s"+ str(line))
                        
                    
#                    print( file.name,"===", line)
                               
#                with open(self.filename, "r") as f:
#                    if self.filename.endswith(".cpp"):
#                        lines = f.readlines()
#                        for line in lines:
#                            line = line.replace("\n"," ")
#                            line = line.replace("\t"," ")
#                            line = line.strip()
                            
#            for cppFunctionLis in cppFunctionList:
#                logging.info("CPP FUNCTION Name: >>>"+ asmcppMethodLis.get_name() )
        
        logging.info("Links creation completed successfully...! [CppAsmExtension]")

