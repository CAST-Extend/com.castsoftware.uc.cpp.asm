##############################################################################################
#---------------------------------------------------------------------------------------------
# Created on 
#
# Author: Thangadurai Kandhasamy<t.kandhasamy@castsoftware.com> - TKA
#
# Description: 
#---------------------------------------------------------------------------------------------
##############################################################################################


class CppAsmValidators(object):
    '''
    classdocs
    '''
   
    def __init__(self, params):
        '''
        Constructor
        '''
    CPP_externCPattern = "(?:^|\W)extern\s+\"C\".*\s+(\w+)\(\s*.*\)\s*\;"
    
    CPP_legacyLinkage = "pragma\s+linkage\((\w+)"
    
    CPP_externOSPattern = "(?:^|\W)extern\s+\"OS\".*\s+(\w+)\(\s*.*\)\s*\;"
    
    ASM_mod = "(\w+)\s*\:\s*$"
    
    ASM_global = "(?:^|\W)global\s+(\w+)\s*$"
    
    ASM_Csect = "(\w+)\s+CSECT\s*$"
    
    cppEmbedded = "(?:^|\W)(__asm__|asm)\s*\("
    
    ASM_CPP_MethodName = "(?:^|\W)V\((\W+\w+)\)"
    
    CPP_PragmaMap = "pragma\s+map\s*\(\s*(\w+)\s*\,\s*\""
    
    CPP_Extern_Function_Impl = "(?:^|\W)extern\s+\"OS\".*\s+(\w+)\(\s*.*\)\s*\{"
    
    