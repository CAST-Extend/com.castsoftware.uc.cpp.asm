##############################################################################################
#---------------------------------------------------------------------------------------------
# Created on 
#
# Author: Thangadurai Kandhasamy<t.kandhasamy@castsoftware.com> - TKA
#
# Description: 
#---------------------------------------------------------------------------------------------
##############################################################################################

import logging
from cast.application import create_link


class CppAsmLinker(object):
    '''
    classdocs
    '''
   
    def __init__(self, params):
        '''
        Constructor
        '''
    def CppMethodToLegacyLinkage(self, cppMethodList, cppLegacyList):
        try:
            parent = None
            child = None
            for cppMethodLis in cppMethodList:
        #        logging.info("CppFunction = "+ cppFunctionLis.get_name() )
                for cppLegacyLis in cppLegacyList:
                    if cppMethodLis.get_name() == cppLegacyLis.get_name() :
#                        logging.info("C_METHOD = "+ str(cppMethodLis.get_fullname()) +"="+  str(cppLegacyLis.get_fullname()) )
        #            if str(cppMethodLis.get_fullname()) == str(cppLegacyLis.get_fullname()) :               
#                        logging.info("ExternC = "+ cppLegacyLis.get_name() )
                        parent = cppMethodLis
                        child = cppLegacyLis
                        logging.info("Link this Parent ["+ str(parent.name) +"] to child ["+ str(child.name) +"]")
                        create_link("callLink", parent, child)
                        logging.info("Link created for [C_METHOD-CPP_LEGACY_LINKAGE] : ["+ str(parent.name) +"] and ["+ str(child.name) +"]" )
        except Exception as e:
            logging.error("CppAsm : Exception in C_METHOD to CPP_LEGACY_LINKAGE linking : %s", str(e))

    def CppMethodToExternOSCall(self, cppMethodList, cppExternOSList):
        try:
            parent = None
            child = None
            for cppMethodLis in cppMethodList:
#                logging.info("CppFunction = "+ cppMethodLis.get_name() )
                for cppExternOSLis in cppExternOSList:
#                    logging.info("C_METHOD = "+ str(cppMethodLis.get_name()) +"="+  str(cppExternOSLis.get_name()) )
                    if cppMethodLis.get_name() == cppExternOSLis.get_name() :
        #            if str(cppMethodLis.get_fullname()) == str(cppExternOSLis.get_fullname()) :               
#                        logging.info("cppExternOSLis_Matched = "+ cppExternOSLis.get_name() )
                        parent = cppMethodLis
                        child = cppExternOSLis
                        logging.info("Link this Parent ["+ str(parent.name) +"] to child ["+ str(child.name) +"]")
                        create_link("callLink", parent, child)
                        logging.info("Link created for [C_METHOD-CPP_EXTERN_OS] : ["+ str(parent.name) +"] and ["+ str(child.name) +"]" )
        except Exception as e:
            logging.error("CppAsm : Exception in C_METHOD to CPP_EXTERN_OS linking : %s", str(e))

    def CppFunctionToLegacyLinkage(self, cppFunctionList, cppLegacyList):
        try:
            parent = None
            child = None
            for cppFunctionLis in cppFunctionList:
        #        logging.info("CppFunction = "+ cppFunctionLis.get_name() )
                for cppLegacyLis in cppLegacyList:
                    if cppFunctionLis.get_name() == cppLegacyLis.get_name() :
#                        logging.info("ExternC_Outer = "+ str(cppFunctionLis.get_fullname()) +"="+  str(cppLegacyLis.get_fullname()) )
        #            if str(cppFunctionLis.get_fullname()) == str(cppLegacyLis.get_fullname()) :               
#                        logging.info("ExternC = "+ cppLegacyLis.get_name() )
                        parent = cppFunctionLis
                        child = cppLegacyLis
                        logging.info("Link this Parent ["+ str(parent.name) +"] to child ["+ str(child.name) +"]")
                        create_link("callLink", parent, child)
                        logging.info("Link created for [CppFunction-ExternC] : ["+ str(parent.name) +"] and ["+ str(child.name) +"]" )
        except Exception as e:
            logging.error("CppAsm : Exception in C_FUNCTION to CPP_LEGACY_LINKAGE linking : %s", str(e))

    def CppFunctionToExternOSCall(self, cppFunctionList, cppExternOSList):
        try:
            parent = None
            child = None
            for cppFunctionLis in cppFunctionList:
#                logging.info("CppFunction = "+ cppFunctionLis.get_name() )
                for cppExternOSLis in cppExternOSList:
#                    logging.info("cppExternOSLis = "+ str(cppFunctionLis.get_name()) +"="+  str(cppExternOSLis.get_name()) )
                    if cppFunctionLis.get_name() == cppExternOSLis.get_name() :
        #            if str(cppFunctionLis.get_fullname()) == str(cppExternOSLis.get_fullname()) :               
#                        logging.info("cppExternOSLis_Matched = "+ cppExternOSLis.get_name() )
                        parent = cppFunctionLis
                        child = cppExternOSLis
                        logging.info("Link this Parent ["+ str(parent.name) +"] to child ["+ str(child.name) +"]")
                        create_link("callLink", parent, child)
                        logging.info("Link created for [CppFunction-ExternC] : ["+ str(parent.name) +"] and ["+ str(child.name) +"]" )
        except Exception as e:
            logging.error("CppAsm : Exception in C_FUNCTION to CPP_LEGACY_LINKAGE linking : %s", str(e))

    def CppExternOSToAsmSect(self, cppExternOSList, asmSect):
        try:
            parent = None
            child = None
            for cppExternOSLis in cppExternOSList:
        #        logging.info("CppFunction = "+ cppExternOSLis.get_name() )
                for asmSec in asmSect:
                    if cppExternOSLis.get_name() == asmSec.get_name() :
#                        logging.info("ExternC_Outer = "+ str(cppExternOSLis.get_fullname()) +"="+  str(asmSec.get_fullname()) )
        #            if str(cppExternOSLis.get_fullname()) == str(asmSec.get_fullname()) :               
#                        logging.info("ExternC = "+ asmSec.get_name() )
                        parent = cppExternOSLis
                        child = asmSec
                        logging.info("Link this Parent ["+ str(parent.name) +"] to child ["+ str(child.name) +"]")
                        create_link("callLink", parent, child)
                        logging.info("Link created for [CPP_EXTERN_OS-ASM_SECT] : ["+ str(parent.name) +"] and ["+ str(child.name) +"]" )
        except Exception as e:
            logging.error("CppAsm : Exception in CPP_EXTERN_OS to ASM_SECT linking : %s", str(e))

    def CppLegacyLinkageToAsmSect(self, cppLegacyList, asmSect):
        try:
            parent = None
            child = None
            for cppLegacyLis in cppLegacyList:
        #        logging.info("CppFunction = "+ cppLegacyLis.get_name() )
                for asmSec in asmSect:
                    if cppLegacyLis.get_name() == asmSec.get_name() :
#                        logging.info("ExternC_Outer = "+ str(cppLegacyLis.get_fullname()) +"="+  str(asmSec.get_fullname()) )
        #            if str(cppLegacyLis.get_fullname()) == str(asmSec.get_fullname()) :               
#                        logging.info("ExternC = "+ asmSec.get_name() )
                        parent = cppLegacyLis
                        child = asmSec
                        logging.info("Link this Parent ["+ str(parent.name) +"] to child ["+ str(child.name) +"]")
                        create_link("callLink", parent, child)
                        logging.info("Link created for [CPP_LEGACY_LINKAGE-ASM_SECT] : ["+ str(parent.name) +"] and ["+ str(child.name) +"]" )
        except Exception as e:
            logging.error("CppAsm : Exception in CPP_LEGACY_LINKAGE to ASM_SECT linking : %s", str(e))

    def CppFunctionToExternC(self, cppFunctionList, cppExternCList):
        try:
            parent = None
            child = None
            for cppFunctionLis in cppFunctionList:
        #        logging.info("CppFunction = "+ cppFunctionLis.get_name() )
                for cppExternCLis in cppExternCList:
                    if cppFunctionLis.get_name() == cppExternCLis.get_name() :
#                        logging.info("ExternC_Outer = "+ str(cppFunctionLis.get_fullname()) +"="+  str(cppExternCLis.get_fullname()) )
        #            if str(cppFunctionLis.get_fullname()) == str(cppExternCLis.get_fullname()) :               
#                        logging.info("ExternC = "+ cppExternCLis.get_name() )
                        parent = cppFunctionLis
                        child = cppExternCLis
                        logging.info("Link this Parent ["+ str(parent.name) +"] to child ["+ str(child.name) +"]")
                        create_link("callLink", parent, child)
                        logging.info("Link created for [C_FUNCTION-CPP_EXTERN_C] : ["+ str(parent.name) +"] and ["+ str(child.name) +"]" )
        except Exception as e:
            logging.error("CppAsm : Exception in C_FUNCTION to CPP_EXTERN_C linking : %s", str(e))

    def CppExternCToAsmGlobal(self, asmGlobalList, cppExternCList):
        try:
            parent = None
            child = None
            for asmGlobalLis in asmGlobalList:
#                logging.debug("ASM_Global = "+ asmGlobalLis.get_name() )
                for cppExternCLis in cppExternCList:
                    if asmGlobalLis.get_name() == cppExternCLis.get_name() :
#                        logging.info("ExternC = "+ cppExternCLis.get_name() )
                        parent = cppExternCLis
                        child = asmGlobalLis
                        logging.info("Link this Parent ["+ str(parent.name) +"] to child ["+ str(child.name) +"]")
                        create_link("callLink", parent, child)
                        logging.info("Link created for [CPP_EXTERN_C-ASM_GLOBAL] : ["+ str(parent.name) +"] and ["+ str(child.name) +"]" )
        except Exception as e:
            logging.error("CppAsm : Exception in CPP_EXTERN_C to ASM_GLOBAL linking : %s", str(e))

    def AsmGlobalToAsmModule(self, asmGlobalList, asmModuleList):
        try:
            parent = None   
            child = None
            for asmGlobalLis in asmGlobalList:
#                logging.debug("Global = "+ asmGlobalLis.get_name() )
                for asmModuleLis in asmModuleList:
                    if asmGlobalLis.get_name()+":" == asmModuleLis.get_name() :
#                        logging.info("Module = "+ asmModuleLis.get_name() )
                        parent = asmGlobalLis
                        child = asmModuleLis
                        logging.info("Link this Parent ["+ str(parent.name) +"] to child ["+ str(child.name) +"]")
                        create_link("callLink", parent, child)
                        logging.info("Link created for [ASM_GLOBAL-ASM_MODULE] : ["+ str(parent.name) +"] and ["+ str(child.name) +"]" )
        except Exception as e:
            logging.error("CppAsm : Exception in ASM_GLOBAL to ASM_MODULE linking : %s", str(e))


    def AsmSectToAsmcppMethodCall(self, asmcppMethodList, asmSect):
        try:
            parent = None
            child = None
            for asmcppMethodLis in asmcppMethodList:
        #        logging.info("CppFunction = "+ cppExternOSLis.get_name() )
                for asmSec in asmSect:
#                        logging.info("ExternC_Outer = "+ str(cppExternOSLis.get_fullname()) +"="+  str(asmSec.get_fullname()) )
    #            if str(cppExternOSLis.get_fullname()) == str(asmSec.get_fullname()) :               
#                        logging.info("ExternC = "+ asmSec.get_name() )

                    if asmcppMethodLis.get_fullname() == asmSec.get_fullname() :
                        parent = asmSec
                        child = asmcppMethodLis
                        logging.info("Link this Parent ["+ str(parent.name) +"] to child ["+ str(child.name) +"]")
                        create_link("callLink", parent, child)
                        logging.info("Link created for [ASM_CPP_METHOD-ASM_SECT] : ["+ str(parent.name) +"] and ["+ str(child.name) +"]" )
        except Exception as e:
            logging.error("CppAsm : Exception in ASM_CPP_METHOD to ASM_SECT linking : %s", str(e))

        