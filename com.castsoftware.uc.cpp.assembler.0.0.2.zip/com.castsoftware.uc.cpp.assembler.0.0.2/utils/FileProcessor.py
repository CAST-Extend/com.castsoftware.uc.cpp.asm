##############################################################################################
#---------------------------------------------------------------------------------------------
# Created on 
#
# Author: Thangadurai Kandhasamy<t.kandhasamy@castsoftware.com> - TKA
#
# Description: 
#---------------------------------------------------------------------------------------------
##############################################################################################

import re
from cast.analysers import log as Print, CustomObject
from utils.CppAsmPatterns import CppAsmValidators as cppAsmPattern

class CppProcessor(object):
    '''
    classdocs
    '''
   
    def __init__(self, params):
        '''
        Constructor
        '''
    
    def ProcessCpp(self, f):
        lines = f.readlines()
        for line in lines:
            line = line.replace("\n"," ")
            line = line.replace("\t"," ")
            line = line.strip()
#                    Print.debug(self.filename +"[xxxxx]"+ str(line) )
#                    externCPat = re.findall("extern\s+\"\C\"\s+(\w*.*)", line)
            try:
                externCPats = re.findall( cppAsmPattern.CPP_externCPattern, line)
                if externCPats:
                    for externCPat in externCPats:
                        cppAsmUnit=CustomObject()
                        self.saveObject(cppAsmUnit, externCPat.strip(), "CPP_EXTERN_C", self.file, self.filename, "CPP_EXTERN_C_"+externCPat.strip() )
                        Print.debug("CPP_EXTERN_C Artifacts created...[" + cppAsmUnit.name +"]")
                        cppAsmUnit.save()
            except Exception as e:
                Print.debug("CppAsm : Error Creating CPP_EXTERN_C Artifact : %s"+ str(line))
        
            try:
#                    externOSPat = re.findall("extern\s+\"OS\"\s+(\w+.*)", line)
                externOSPats = re.findall( cppAsmPattern.CPP_externOSPattern , line)
                if externOSPats:
                    for externOSPat in externOSPats:
                        cppAsmUnit=CustomObject()
                        self.saveObject(cppAsmUnit, externOSPat.strip(), "CPP_EXTERN_OS", self.file, self.filename, "CPP_EXTERN_OS_"+externOSPat.strip() )
                        Print.debug("CPP_EXTERN_OS Artifacts created...[" + cppAsmUnit.name +"]")
                        cppAsmUnit.save()
            except Exception as e:
                Print.debug("CppAsm : Error Creating CPP_EXTERN_OS Artifact : %s"+ str(line))
                    
            try:
#                    legacyLinkage = re.findall("pragma\s+linkage\((\w+)", line)
                legacyLinkages = re.findall( cppAsmPattern.CPP_legacyLinkage, line)
                if legacyLinkages:
                    for legacyLinkage in legacyLinkages:
                        cppAsmUnit=CustomObject()
                        self.saveObject(cppAsmUnit, legacyLinkage.strip(), "CPP_LEGACY_LINKAGE", self.file, self.filename, "CPP_LEGACY_LINKAGE_"+legacyLinkage.strip() )
                        Print.debug("CPP_LEGACY_LINKAGE Artifacts created...[" + cppAsmUnit.name +"]")
                        cppAsmUnit.save()
            except Exception as e:
                Print.debug("CppAsm : Error Creating CPP_LEGACY_LINKAGE Artifact : %s"+ str(line))

            try:
#                    legacyLinkage = re.findall("pragma\s+linkage\((\w+)", line)
                pragmaMaps = re.findall( cppAsmPattern.CPP_PragmaMap, line)
                if pragmaMaps:
                    for pragmaMap in pragmaMaps:
                        cppAsmUnit=CustomObject()
                        self.saveObject(cppAsmUnit, pragmaMap.strip(), "CPP_PRAGMA_MAP_FUNCTION", self.file, self.filename, "CPP_PRAGMA_MAP_FUNCTION"+pragmaMap.strip() )
                        Print.debug("CPP_PRAGMA_MAP_FUNCTION Artifacts created...[" + cppAsmUnit.name +"]")
                        cppAsmUnit.save()
            except Exception as e:
                Print.debug("CppAsm : Error Creating CPP_PRAGMA_MAP_FUNCTION Artifact : %s"+ str(line))


            try:
                externFunctionImpls = re.findall( cppAsmPattern.CPP_legacyLinkage, line)
                if externFunctionImpls:
                    for externFunctionImpl in externFunctionImpls:
                        cppAsmUnit=CustomObject()
                        self.saveObject(cppAsmUnit, externFunctionImpl.strip(), "CPP_EXTERN_OS_IMPL", self.file, self.filename, "CPP_EXTERN_OS_IMPL_"+externFunctionImpl.strip() )
                        Print.debug("CPP_EXTERN_OS_IMPL Artifacts created...[" + cppAsmUnit.name +"]")
                        cppAsmUnit.save()
            except Exception as e:
                Print.debug("CppAsm : Error Creating CPP_EXTERN_OS_IMPL Artifact : %s"+ str(line))

      


class AsmProcessor(object):
    
    def ProcessAsm(self, f):
        globNam = []
        lines = f.readlines()
        for line in lines:
            line = line.replace("\n"," ")
            line = line.replace("\t"," ")
            line = line.strip()
#                    Print.debug(self.filename +"[xxxxx]"+ str(line) )
            
#                    asmGlobNames = "(?:^|\W)global\s+(\w+)"
#                    asmModPatts = "(\w+)\s*\:"
#                    asmCsects = "(\w+)\s+CSECT\s*$"
            try:
                asmGlobNames = re.findall( cppAsmPattern.ASM_global, line)
                if asmGlobNames:
                    for asmGlobName in asmGlobNames:
                        Print.debug("ASM_GLOBAL ----["+ asmGlobName +"]")
                        globNam.append(asmGlobName)
                        cppAsmUnit=CustomObject()
                        self.saveObject(cppAsmUnit, asmGlobName.strip(), "ASM_GLOBAL", self.file, self.filename, "ASM_GLOBAL_"+asmGlobName.strip() )
                        Print.debug("Global ASM_GLOBAL Artifacts created..." + cppAsmUnit.name )
                        cppAsmUnit.save()
            except Exception as e:
                Print.debug("CppAsm : Error Creating ASM_GLOBAL Artifact : %s"+ str(line))
    
            try:
                asmModPatts = re.findall( cppAsmPattern.ASM_mod, line)
                if asmModPatts:
                    for asmModPatt in asmModPatts:
                        if asmModPatt in globNam:
                            Print.debug("ASM_MODULE ["+asmModPatt+"]<:>  - IMPLEMENTATION HERE")
                            cppAsmUnit=CustomObject()
                            self.saveObject(cppAsmUnit, asmModPatt.strip()+":", "ASM_MODULE", self.file, self.filename, "ASM_MODULE_"+asmModPatt.strip() )
                            Print.debug("ASM_MODULE Artifacts created..." + cppAsmUnit.name )
                            cppAsmUnit.save()
#                        Print.debug("exec_I_obj----", exec_obj)    
            except Exception as e:
                Print.debug("CppAsm : Error Creating ASM_MODULE Artifact : %s"+ str(line))

            try:
                asmCsects = re.findall( cppAsmPattern.ASM_Csect, line)
                if asmCsects:
                    for asmCsect in asmCsects:
                        Print.debug("ASM_SECT name is ["+ asmCsect +"]")
                        cppAsmUnit=CustomObject()
                        self.saveObject(cppAsmUnit, asmCsect.strip(), "ASM_SECT", self.file, self.filename, "ASM_SECT_"+asmCsect.strip() )
                        Print.debug("CSECT ASM_SECT Artifacts created..." + cppAsmUnit.name )
                        cppAsmUnit.save()
            except Exception as e:
                Print.debug("CppAsm : Error Creating ASM_SECT Artifact : %s"+ str(line))
                             

            try:
                asmCppMethods = re.findall( cppAsmPattern.ASM_CPP_MethodName, line)
                if asmCppMethods:
                    for asmCppMethod in asmCppMethods:
                        Print.debug("ASM_CPP_METHOD name is ["+ asmCppMethod +"]")
                        cppAsmUnit=CustomObject()
                        self.saveObject(cppAsmUnit, asmCppMethod.strip(), "ASM_CPP_METHOD", self.file, self.filename, "ASM_CPP_METHOD_"+asmCppMethod.strip() )
                        Print.debug("ASM_CPP_METHOD Artifacts created..." + cppAsmUnit.name )
                        cppAsmUnit.save()
            except Exception as e:
                Print.debug("CppAsm : Error Creating ASM_CPP_METHOD Artifact : %s"+ str(line))
                             
                
