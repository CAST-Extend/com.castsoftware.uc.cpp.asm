##############################################################################################
#---------------------------------------------------------------------------------------------
# Created on 
#
# Author: Thangadurai Kandhasamy<t.kandhasamy@castsoftware.com> - TKA
#
# Description: 
#---------------------------------------------------------------------------------------------
##############################################################################################

import cast.analysers.ua
from cast.analysers import log as Print
import binascii
import os
from os import listdir
from os import walk
import traceback
from os.path import basename, splitext
from sqlalchemy.event import legacy

from utils.FileProcessor import CppProcessor as cppProcess
from utils.FileProcessor import AsmProcessor as asmProcess



class CppAsmExtension(cast.analysers.ua.Extension):
    
    def __init__(self):
        Print.debug("Inside __init__ CppAsmExtension")
        self.filename = ""
        self.name = ""
        self.file = ""    
        self.initial_crc =  None
        self.file_ref=""
        self.asdArtfct = [ ]
        self.jv_obj = [ ]
        #self.active = True
        #self.extensions = ['.asm','.cpp','.cc']
        #return
#     def cast.analysers.get_ua_options()
#         pass

    def start_analysis(self):
        Print.debug("Inside start_analysis CppAsmExtension")
        pass
       
     
    def start_file(self,file):
        Print.debug("Inside start_file CppAsmExtension")
#         if not self.active:
#             Print.debug("Made Inactive")
#         self.filename = file.get_path().lower()
#         _, ext = os.path.splitext(self.filename)
#         if not ext in self.extensions:
#             Print.debug("Condition file--" +str(ext))
#             return
        self.file = file
        self.filename = file.get_path()
        self.createCppAsmobject();
        #Print.debug("self.name----" + str(self.name))       
        pass

                      

    def saveObject(self,obj_reference,name,obj_type,parent,fullname,guid):
        Print.debug("Saving Object : "+ name)
        obj_reference.set_name(name)
        obj_reference.set_type(obj_type)
        obj_reference.set_fullname(fullname)
        obj_reference.set_parent(parent)
        obj_reference.set_guid(guid) 
        pass
    

    def end_analysis(self):        
        Print.debug("Inside end_analysis: CppAsmExtension")
        pass
    
    def createCppAsmobject(self):
        
        with open(self.filename, "r") as f:
            # current line number
            if self.filename.endswith(".cpp"):
                cppProcess.ProcessCpp(self, f)
        
            if self.filename.endswith(".asm"):
                asmProcess.ProcessAsm(self, f)
        
            Print.debug("End of Analysis!!!") 
        

        
        
            
    def getcrc(self,text, initial_crc = 0):
        return binascii.crc32(text, initial_crc)  - 2**31